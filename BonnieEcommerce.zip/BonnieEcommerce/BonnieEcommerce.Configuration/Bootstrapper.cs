﻿using BonnieEcommerce.API;
using BonnieEcommerce.Configuration.Swashbuckle;

namespace BonnieEcommerce.Configuration
{
    public static class Bootstrapper
    {
        public static IServiceCollection AddUsers(this IServiceCollection services, IConfiguration configuration)
           => services.AddShoppingCartServices()
                      .AddSwagger();
    //    public static IEndpointRouteBuilder UseUserEndpoints(this IEndpointRouteBuilder endpoints)
    //  => endpoints.UseRegisterUserEndpoints();

    //    public static IEndpointRouteBuilder UseShoppingCartEndpoints(this IEndpointRouteBuilder endpoints)
    //=> endpoints.UseShoppingCartEndpoints();



    }
}
