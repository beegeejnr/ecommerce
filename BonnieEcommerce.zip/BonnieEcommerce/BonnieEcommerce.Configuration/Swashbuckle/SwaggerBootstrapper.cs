﻿using Microsoft.OpenApi.Models;

namespace BonnieEcommerce.Configuration.Swashbuckle
{
    public static class SwaggerBootstrapper
    {
        public static IServiceCollection AddSwagger(this IServiceCollection services)
        {

            services.AddEndpointsApiExplorer()
                .AddSwaggerGen(c =>
                {
                    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Bonnie E-commerce Shopping Cart API", Version = "v1" });
                });
            return services;
        }
    }
}
