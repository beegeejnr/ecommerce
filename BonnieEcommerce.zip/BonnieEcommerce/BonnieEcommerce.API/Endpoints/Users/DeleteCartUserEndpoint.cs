﻿namespace BonnieEcommerce.API.Endpoints.Users
{
       public static class DeleteCartUserEndpoint
    {
        internal static IEndpointRouteBuilder UseDeleteCartUserEndpoint(this IEndpointRouteBuilder endpoints)
        {
            endpoints.MapDelete("users/{id}", Users.DeleteCartUser)
            .Produces(StatusCodes.Status204NoContent);

            // .RequireAuthorization();
            return endpoints;
        }


    }
}
