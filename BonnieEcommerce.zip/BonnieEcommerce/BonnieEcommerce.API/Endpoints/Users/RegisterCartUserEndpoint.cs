﻿using BonnieEcommerce.Contracts.DTOs;

namespace BonnieEcommerce.API.Endpoints.Users
{

    public static class RegisterCartUserEndpoint
    {
        internal static IEndpointRouteBuilder UseRegisterCartUserEndpoint(this IEndpointRouteBuilder endpoints)
        {
            endpoints.MapPost("users", Users.RegisterCartUser)
            .Produces(StatusCodes.Status200OK, typeof(CartUserDTO));

            // .RequireAuthorization();
            return endpoints;
        }
    }
}
