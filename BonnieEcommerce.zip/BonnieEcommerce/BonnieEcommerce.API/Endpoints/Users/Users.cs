﻿using BonnieEcommerce.Contracts.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace BonnieEcommerce.API.Endpoints.Users
{
    public class Users
    {
        public static Task RegisterCartUser([FromBody] CartUserDTO cartUser)
        {
            throw new NotImplementedException();
        }

        internal static Task DeleteCartUser([FromQuery] Guid id)
        {
            throw new NotImplementedException();
        }

    }
}
