﻿using BonnieEcommerce.Contracts.DTOs;

namespace BonnieEcommerce.API.Endpoints.ShoppingCarts
{
    public static class UpdateShoppingCartEndpoint
    {
        internal static IEndpointRouteBuilder UseUpdateShoppingCartEndpoint(this IEndpointRouteBuilder endpoints)
        {
            endpoints.MapPut("shopping-carts", ShoppingCarts.UpdateShoppingCartEndpoint)
            .Produces(StatusCodes.Status202Accepted, typeof(ShoppingCartDTO))
            ;//.RequireAuthorization();
            return endpoints;
        }

    }
}
