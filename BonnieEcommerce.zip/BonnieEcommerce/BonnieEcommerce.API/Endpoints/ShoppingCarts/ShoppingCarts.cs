﻿using BonnieEcommerce.Contracts.DTOs;
using BonnieEcommerce.Core.Orchestrators;
using Microsoft.AspNetCore.Mvc;

namespace BonnieEcommerce.API.Endpoints.ShoppingCarts
{
    public static class ShoppingCarts
    {
        public static async Task<ShoppingCartDTO> CreateCartEndpoint([FromBody] NewShoppingCartDTO newShoppingCart)
        {
            return await ShoppingCartOrchestrator.CreateCart(newShoppingCart);
        }
        internal static async Task<CartItemDTO> AddShoppingCartItemEndpoint([FromQuery] Guid id, [FromBody] CartItemDTO cartItemDTO)
        {
            return await ShoppingCartOrchestrator.AddShoppingCartItem(id, cartItemDTO);
        }
        internal static async Task<bool> DeleteShoppingCartEndpoint([FromQuery] Guid id)
        {
            return await ShoppingCartOrchestrator.DeleteShoppingCart(id);
        }
        internal static async Task<bool> RemoveShoppingCartItemEndpoint([FromQuery] Guid cartId, [FromQuery] Guid itemId)
        {
            return await ShoppingCartOrchestrator.RemoveShoppingCartItem(cartId, itemId);
        }
        internal static async Task<ShoppingCartDTO> UpdateShoppingCartEndpoint([FromBody] ShoppingCartDTO cartDTO)
        {
            return await ShoppingCartOrchestrator.UpdateShoppingCart(cartDTO);
        }
        internal static async Task<CartItemDTO> UpdateShoppingCartItemEndpoint([FromQuery] Guid cartId, [FromBody] CartItemDTO cartItemDTO)
        {
            return await ShoppingCartOrchestrator.UpdateShoppingCartItem(cartId, cartItemDTO);
        }
    }
}
