﻿using BonnieEcommerce.Contracts.DTOs;

namespace BonnieEcommerce.API.Endpoints.ShoppingCarts
{
    public static class UpdateShoppingCartItemEndpoint
    {
        internal static IEndpointRouteBuilder UseUpdateShoppingCartItemEndpoint(this IEndpointRouteBuilder endpoints)
        {
            endpoints.MapPut("shopping-carts/{id}/items", ShoppingCarts.UpdateShoppingCartItemEndpoint)
            .Produces(StatusCodes.Status202Accepted, typeof(CartItemDTO))
            ;//.RequireAuthorization();
            return endpoints;
        }

    }
}
