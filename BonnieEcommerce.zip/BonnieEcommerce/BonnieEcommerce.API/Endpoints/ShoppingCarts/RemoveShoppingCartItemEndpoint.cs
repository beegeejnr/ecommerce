﻿using BonnieEcommerce.Contracts.DTOs;

namespace BonnieEcommerce.API.Endpoints.ShoppingCarts
{
    public static class RemoveShoppingCartItemEndpoint
    {
        internal static IEndpointRouteBuilder UseRemoveShoppingCartItemEndpoint(this IEndpointRouteBuilder endpoints)
        {
            endpoints.MapDelete("shopping-carts/{cartId}/items/{itemId}", ShoppingCarts.RemoveShoppingCartItemEndpoint)
            .Produces(StatusCodes.Status204NoContent)
            ;//.RequireAuthorization();
            return endpoints;
        }

    }
}
