﻿using BonnieEcommerce.Contracts.DTOs;

namespace BonnieEcommerce.API.Endpoints.ShoppingCarts
{
    public static class CreateCartEndpoint
    {
        internal static IEndpointRouteBuilder UseCreateCartEndpoint(this IEndpointRouteBuilder endpoints)
        {
            endpoints.MapPost("shopping-carts", ShoppingCarts.CreateCartEndpoint)
            .Produces(StatusCodes.Status201Created, typeof(NewShoppingCartDTO))
            ;//.RequireAuthorization();
            return endpoints;
        }

    }
}
