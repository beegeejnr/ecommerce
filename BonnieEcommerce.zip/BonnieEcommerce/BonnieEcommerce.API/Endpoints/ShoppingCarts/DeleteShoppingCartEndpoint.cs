﻿using BonnieEcommerce.Contracts.DTOs;

namespace BonnieEcommerce.API.Endpoints.ShoppingCarts
{
       public static class DeleteShoppingCartEndpoint
    {
        internal static IEndpointRouteBuilder UseDeleteShoppingCartEndpoint(this IEndpointRouteBuilder endpoints)
        {
            endpoints.MapDelete("shopping-carts/{id}", ShoppingCarts.DeleteShoppingCartEndpoint)
            .Produces(StatusCodes.Status204NoContent)
            ;//.RequireAuthorization();
            return endpoints;
        }


    }
}
