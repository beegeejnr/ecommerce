﻿using BonnieEcommerce.Contracts.DTOs;
namespace BonnieEcommerce.API.Endpoints.ShoppingCarts
{
    public static class AddShoppingCartItemEndpoint
    {
        internal static IEndpointRouteBuilder UseAddShoppingCartItemEndpoint(this IEndpointRouteBuilder endpoints)
        {
            endpoints.MapPost("shopping-carts/{id}/items", ShoppingCarts.AddShoppingCartItemEndpoint)
            .Produces(StatusCodes.Status201Created, typeof(CartItemDTO))
            ;// .RequireAuthorization();
            return endpoints;
        }


    }
}
