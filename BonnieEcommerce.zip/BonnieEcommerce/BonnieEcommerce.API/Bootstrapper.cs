﻿using BonnieEcommerce.API.Endpoints.ShoppingCarts;
using BonnieEcommerce.API.Endpoints.Users;
using BonnieEcommerce.Contracts.Repositories;
using BonnieEcommerce.Infrastructure.Data.Repositories;

namespace BonnieEcommerce.API
{
    public static class Bootstrapper
    {
        public static IServiceCollection AddShoppingCartServices(this IServiceCollection services)
        {
            services.AddControllers();
            services.AddTransient<IShoppingCartRepository, SQLShoppingCartRepository>();
            services.AddHttpClient();
            services.AddHttpContextAccessor();
            return services;
        }

        public static IEndpointRouteBuilder UseUsersEndpoints(this IEndpointRouteBuilder endpoints)
            => endpoints
            .UseRegisterCartUserEndpoint()
            .UseDeleteCartUserEndpoint();
        public static IEndpointRouteBuilder UseShoppingCartsEndpoints(this IEndpointRouteBuilder endpoints)
            => endpoints
            .UseCreateCartEndpoint()
            .UseAddShoppingCartItemEndpoint()
            .UseUpdateShoppingCartEndpoint()
            .UseDeleteShoppingCartEndpoint()
            .UseRemoveShoppingCartItemEndpoint();

    }
}
