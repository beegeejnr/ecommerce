﻿using BonnieEcommerce.Contracts.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BonnieEcommerce.Core.Orchestrators
{
    public static class ShoppingCartOrchestrator
    {
        public static Task<ShoppingCartDTO> CreateCart(NewShoppingCartDTO newShoppingCart) { throw new NotImplementedException(); }
        public static Task<CartItemDTO> AddShoppingCartItem(Guid id, CartItemDTO cartItemDTO) { throw new NotImplementedException(); }
        public static Task<bool> DeleteShoppingCart(Guid id) { throw new NotImplementedException(); }
        public static Task<bool> RemoveShoppingCartItem(Guid cartId, Guid itemId) { throw new NotImplementedException(); }
        public static Task<ShoppingCartDTO> UpdateShoppingCart(ShoppingCartDTO cartDTO) { throw new NotImplementedException(); }
        public static Task<CartItemDTO> UpdateShoppingCartItem(Guid cartId, CartItemDTO cartItemDTO) { throw new NotImplementedException(); }
    }
}
