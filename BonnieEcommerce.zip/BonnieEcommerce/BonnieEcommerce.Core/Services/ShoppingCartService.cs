﻿using BonnieEcommerce.Contracts.DTOs;
using BonnieEcommerce.Contracts.Services;

namespace BonnieEcommerce.Core.Services
{
    public class ShoppingCartService : IShoppingCartService
    {
        public Task<CartItemDTO> AddCartItem(CartItemDTO shoppingCartDTO)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteCartItem(NewShoppingCartDTO shoppingCartDTO)
        {
            throw new NotImplementedException();
        }

        public Task<ShoppingCartDTO> GetUserCart(Guid userId)
        {
            throw new NotImplementedException();
        }

        public Task<NewShoppingCartDTO> RegisterCart(NewShoppingCartDTO shoppingCartDTO)
        {
            throw new NotImplementedException();
        }

        public Task<CartUserDTO> RegisterUser(CartUserDTO cartUser)
        {
            throw new NotImplementedException();
        }

        public Task<CartItemDTO> UpdateCartItem(CartItemDTO shoppingCartDTO)
        {
            throw new NotImplementedException();
        }
    }
}
