﻿namespace BonnieEcommerce.API.Host.Configuration
{
    public class LoggingConfiguration
    {
    }
}
