﻿
using BonnieEcommerce.Configuration;


namespace BonnieEcommerce.API.Host.Configuration
{
    public static class ApplicationConfiguration
    {
        public static IApplicationBuilder ConfigureApp(this IApplicationBuilder app, IWebHostEnvironment env)
        {
            //if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage()
                    .UseSwagger()
                    .UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Bonnie E-commerce Shopping Cart API"));
            }
          
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthentication();
            app.UseEndpoints(endpoints =>
            {
                endpoints.UseUsersEndpoints();
                endpoints.UseShoppingCartsEndpoints();

            });
            return app;
        }
    }
}

