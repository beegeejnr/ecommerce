
using BonnieEcommerce.API.Host.Configuration;
using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace BonnieEcommerce.API.Host
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {
                options.Authority = "https://dev-eqxrvhqlxkz81l5x.us.auth0.com/";
                options.Audience = "https://bonnie-ecommerce/shoppingcartapi";
            });

            var app = builder.Build();

            app.ConfigureApp(app.Environment);
            

            app.Run();
        }
    }
}