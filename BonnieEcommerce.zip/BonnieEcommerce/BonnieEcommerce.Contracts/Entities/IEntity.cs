﻿using BonnieEcommerce.Contracts.Enums;

namespace BonnieEcommerce.Contracts.Entities
{
    public interface IEntity
    {
        Guid Id { get; set; }
        DateTime DateModified { get; set; }
        EntityState Status { get; set; }
    }
}
