﻿using BonnieEcommerce.Contracts.Enums;

namespace BonnieEcommerce.Contracts.Entities
{
    public class CartUser : IEntity
    {
        public Guid Id { get; set; }
        public DateTime DateModified { get; set; }
        public EntityState Status { get; set; }
    }
}
