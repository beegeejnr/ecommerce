﻿using BonnieEcommerce.Contracts.DTOs;

namespace BonnieEcommerce.Contracts.Orchestrators
{
    public interface IShoppingCartOrchestrator
    {
        Task<ShoppingCartDTO> CreateCartEndpoint(NewShoppingCartDTO newShoppingCart);
        Task<CartItemDTO> AddShoppingCartItemEndpoint(Guid id, CartItemDTO cartItemDTO);
        Task<bool> DeleteShoppingCartEndpoint(Guid id);
        Task<bool> RemoveShoppingCartItemEndpoint(Guid cartId, Guid itemId);
        Task<ShoppingCartDTO> UpdateShoppingCartEndpoint(ShoppingCartDTO cartDTO);
        Task<CartItemDTO> UpdateShoppingCartItemEndpoint(Guid cartId, CartItemDTO cartItemDTO);
    }
}
