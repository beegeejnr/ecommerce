﻿using BonnieEcommerce.Contracts.Entities;

namespace BonnieEcommerce.Contracts.Repositories
{
    public interface ICartUserRepository : IRepository<CartUser>
    {
    }
}
