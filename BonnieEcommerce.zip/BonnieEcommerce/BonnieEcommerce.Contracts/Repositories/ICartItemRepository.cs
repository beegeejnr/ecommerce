﻿using BonnieEcommerce.Contracts.Entities;

namespace BonnieEcommerce.Contracts.Repositories
{
    public interface ICartItemRepository: IRepository<CartItem>
    {
    }
}
