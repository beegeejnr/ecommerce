﻿using BonnieEcommerce.Contracts.Entities;

namespace BonnieEcommerce.Contracts.Repositories
{
    public interface IShoppingCartRepository : IRepository<ShoppingCart>
    {
    }
}
