﻿using BonnieEcommerce.Contracts.DTOs;
using BonnieEcommerce.Contracts.Entities;

namespace BonnieEcommerce.Contracts.Repositories
{
    public interface IRepository<T> where T: IEntity 
    {
        Task<IEnumerable<T>> Search(List<SearchParameter> searchParameters);
        Task<T> Get( Guid id);
        Task<T> Save(T entity);

    }
}
