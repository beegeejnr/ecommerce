﻿namespace BonnieEcommerce.Contracts.DTOs
{
    public class NewShoppingCartDTO
    {
        public CartUserDTO User { get; set; }
        public List<CartItemDTO> Items { get; set; }
    }
}
