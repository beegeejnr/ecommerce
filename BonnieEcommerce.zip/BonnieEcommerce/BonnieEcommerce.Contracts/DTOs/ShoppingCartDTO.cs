﻿using BonnieEcommerce.Contracts.Enums;

namespace BonnieEcommerce.Contracts.DTOs
{
    public class ShoppingCartDTO
    {
        public Guid Id { get; set; }
        public DateTime DateModified { get; set; }
        public EntityState Status { get; set; }
        public CartUserDTO User { get; set; }
        public List<CartItemDTO> Items { get; set; }
    }
}
