﻿namespace BonnieEcommerce.Contracts.Enums
{
    public enum EntityState
    {
        Active,
        Deleted,
    }
}
