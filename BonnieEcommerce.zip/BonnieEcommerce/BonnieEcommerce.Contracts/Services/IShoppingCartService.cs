﻿using BonnieEcommerce.Contracts.DTOs;

namespace BonnieEcommerce.Contracts.Services
{
    public interface IShoppingCartService
    {
        Task<CartUserDTO> RegisterUser(CartUserDTO cartUser);
        Task<NewShoppingCartDTO> RegisterCart(NewShoppingCartDTO shoppingCartDTO);
        Task<CartItemDTO> AddCartItem(CartItemDTO shoppingCartDTO);
        Task<CartItemDTO> UpdateCartItem(CartItemDTO shoppingCartDTO);
        Task<bool> DeleteCartItem(NewShoppingCartDTO shoppingCartDTO);
        Task<ShoppingCartDTO> GetUserCart(Guid userId);

    }
}
