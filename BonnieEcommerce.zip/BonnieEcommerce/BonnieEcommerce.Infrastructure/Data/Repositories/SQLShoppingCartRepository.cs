﻿using BonnieEcommerce.Contracts.DTOs;
using BonnieEcommerce.Contracts.Entities;
using BonnieEcommerce.Contracts.Repositories;

namespace BonnieEcommerce.Infrastructure.Data.Repositories
{
    public class SQLShoppingCartRepository : IShoppingCartRepository
    {
        public Task<ShoppingCart> Get(Guid id)
        {
            throw new NotImplementedException();
        }

        public Task<ShoppingCart> Save(ShoppingCart entity)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<ShoppingCart>> Search(List<SearchParameter> searchParameters)
        {
            throw new NotImplementedException();
        }
    }
}
