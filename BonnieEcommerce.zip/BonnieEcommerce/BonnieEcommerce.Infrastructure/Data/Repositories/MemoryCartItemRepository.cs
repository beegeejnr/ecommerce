﻿using BonnieEcommerce.Contracts.DTOs;
using BonnieEcommerce.Contracts.Entities;
using BonnieEcommerce.Contracts.Repositories;

namespace BonnieEcommerce.Infrastructure.Data.Repositories
{
    public class MemoryCartItemRepository : ICartItemRepository
    {
        public Task<CartItem> Get(Guid id)
        {
            throw new NotImplementedException();
        }

        public Task<CartItem> Save(CartItem entity)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<CartItem>> Search(List<SearchParameter> searchParameters)
        {
            throw new NotImplementedException();
        }
    }
}
