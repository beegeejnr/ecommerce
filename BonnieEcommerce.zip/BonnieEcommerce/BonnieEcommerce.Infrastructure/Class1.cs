﻿namespace BonnieEcommerce.Infrastructure
{
    public class Class1
    {

    }
}